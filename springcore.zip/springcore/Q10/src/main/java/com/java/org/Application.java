package com.java.org;

public class Application {

	public void go() {

		System.out.println("Groot");
	}

}
