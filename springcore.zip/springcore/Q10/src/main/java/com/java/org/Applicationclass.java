package com.java.org;

public class Applicationclass {

	public void walk() {

		System.out.println("Hulk Walk");
	}

	
}
