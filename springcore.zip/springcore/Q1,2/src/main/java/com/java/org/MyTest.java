package com.java.org;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTest {
	
	Customer c1 = new Customer(1,"ATUL","7827238971",new Addresses("DRIZZLING LAND","NA","UTTAR PRADESH","201013","MAHARASHTRA"));
	
    @Test
	public void draw() {
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
		Customer c = (Customer) context.getBean("customer");
		assertEquals(c1.getCustID(), c.getCustID());
		assertEquals(c1.getCustName(), c.getCustName());
	}

}
