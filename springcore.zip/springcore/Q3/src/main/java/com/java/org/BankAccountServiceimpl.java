package com.java.org;

public class BankAccountServiceimpl implements BankAccountService {

	public double withdraw(long accountID, double balance) {
		
		
		return 0;
	}

	public double deposit(long accountID, double balance) {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getBalance(long accountID) {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean fundTransfer(long FromAccount, long toAccount, double amont) {
		// TODO Auto-generated method stub
		return false;
	}

}
