package com.java.org;

public class BankMain {

	public static void main(String[] args) {
		
		

	}

}
