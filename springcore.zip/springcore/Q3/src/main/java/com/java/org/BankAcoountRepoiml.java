package com.java.org;

public class BankAcoountRepoiml implements BankAccountRepo {

	 
	public double getBalance(long accountID) {
		
		return 0;
	}

	public double updateBalance(long accountID, double newBalance) {
		
		return 0;
	}

}
